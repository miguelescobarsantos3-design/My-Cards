// Mis Tarjetas - lector con Claude (Google Cloud Functions, Node 20)
// Recibe el texto o las imágenes de un documento desde la app, verifica que el usuario
// haya entrado con Google (Firebase Auth), revisa sus límites y le pregunta a Claude.
// La clave de Anthropic vive en Secret Manager (variable ANTHROPIC_KEY), nunca en la app.
const functions = require("@google-cloud/functions-framework");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

const ORIGENES = (process.env.ORIGENES || "https://miguelescobarsantos3-design.github.io,http://localhost:8765")
  .split(",").map(s => s.trim()).filter(Boolean);
const LIMITE_USUARIO_MES = Number(process.env.LIMITE_USUARIO_MES || 40); // lecturas por usuario al mes
const LIMITE_TOTAL_MES = Number(process.env.LIMITE_TOTAL_MES || 400);     // tope de toda la app al mes
const ADMINS = (process.env.ADMINS || "miguelescobarsantos3@gmail.com").toLowerCase().split(",").map(s => s.trim()).filter(Boolean);
const LIMITE_ADMIN_MES = Number(process.env.LIMITE_ADMIN_MES || 150);
// Se prueba el primero; si Anthropic ya no lo tiene, se usa el siguiente.
const MODELOS_RAPIDOS = (process.env.MODELO_RAPIDO || "claude-haiku-5-5,claude-haiku-4-5").split(",").map(x => x.trim());
const MODELOS_COMPLETOS = (process.env.MODELO_COMPLETO || "claude-sonnet-5-5,claude-sonnet-4-5").split(",").map(x => x.trim());
const MAX_IMAGENES = 8;

function cors(req, res) {
  const o = req.get("Origin") || "";
  // Se aceptan las direcciones de la lista y cualquier sitio de GitHub Pages o Firebase Hosting (la sesión se valida con el token)
  if (ORIGENES.includes(o) || /^https:\/\/[a-z0-9-]+\.(github\.io|web\.app|firebaseapp\.com)$/i.test(o)) res.set("Access-Control-Allow-Origin", o);
  res.set("Vary", "Origin");
  res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Authorization, Content-Type");
  res.set("Access-Control-Max-Age", "3600");
}

functions.http("leerDocumento", async (req, res) => {
  cors(req, res);
  if (req.method === "OPTIONS") return res.status(204).send("");
  if (req.method !== "POST") return res.status(405).json({ error: "metodo" });
  try {
    // 1) ¿Quién es? (token de Firebase Auth)
    const m = (req.get("Authorization") || "").match(/^Bearer (.+)$/);
    if (!m) return res.status(401).json({ error: "sin_sesion", detalle: "sin_token" });
    let user;
    try { user = await admin.auth().verifyIdToken(m[1]); }
    catch (e) { console.warn("Token no válido:", e.code || "", e.message || ""); return res.status(401).json({ error: "sin_sesion", detalle: e.code || "token" }); }
    // Solo personas autorizadas (lista "permitidos" que maneja el administrador)
    const email = String(user.email || "").toLowerCase();
    const esAdmin = ADMINS.includes(email);
    let verificado = user.email_verified === true;
    if (!verificado) { try { verificado = (await admin.auth().getUser(user.uid)).emailVerified === true; } catch (e) {} }
    if (!email || !verificado) { console.warn("Correo sin confirmar:", email); return res.status(403).json({ error: "no_permitido", detalle: "correo_sin_confirmar" }); }
    if (!esAdmin && !(await db.doc(`permitidos/${email}`).get()).exists) { console.warn("No autorizado:", email); return res.status(403).json({ error: "no_permitido", detalle: "no_autorizado" }); }

    // 2) Validar lo que manda la app
    const b = req.body || {};
    const prompt = String(b.prompt || "");
    if (!prompt || prompt.length > 200000) return res.status(400).json({ error: "prompt" });
    const imagenes = Array.isArray(b.imagenes) ? b.imagenes.slice(0, MAX_IMAGENES) : [];
    for (const im of imagenes) {
      if (!im || !/^image\/(jpeg|png|webp|gif)$/.test(im.tipo) || typeof im.datos !== "string" || im.datos.length > 7_000_000)
        return res.status(400).json({ error: "imagen" });
    }
    const completo = b.nivel === "complex";

    // 3) Límites de uso (por usuario y total del mes)
    const mes = new Date().toISOString().slice(0, 7);
    const refU = db.doc(`uso/${user.uid}_${mes}`), refT = db.doc(`uso/total_${mes}`);
    const ok = await db.runTransaction(async tx => {
      const [u, t] = await Promise.all([tx.get(refU), tx.get(refT)]);
      const nu = (u.exists ? u.data().lecturas : 0) || 0, nt = (t.exists ? t.data().lecturas : 0) || 0;
      if (nu >= (esAdmin ? LIMITE_ADMIN_MES : LIMITE_USUARIO_MES) || nt >= LIMITE_TOTAL_MES) return false;
      tx.set(refU, { lecturas: nu + 1, email: user.email || "", mes }, { merge: true });
      tx.set(refT, { lecturas: nt + 1, mes }, { merge: true });
      return true;
    });
    if (!ok) return res.status(429).json({ error: "limite" });

    // 4) Preguntar a Claude
    const content = imagenes.map(im => ({ type: "image", source: { type: "base64", media_type: im.tipo, data: im.datos } }));
    content.push({ type: "text", text: prompt + (b.json ? "\n\nResponde únicamente con el JSON, sin texto adicional." : "") });
    let r, out;
    for (const model of (completo ? MODELOS_COMPLETOS : MODELOS_RAPIDOS)) {
      r = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "x-api-key": process.env.ANTHROPIC_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model, max_tokens: completo ? 6000 : 2000, messages: [{ role: "user", content }] })
      });
      out = await r.json();
      if (!(r.status === 404 || (out.error && out.error.type === "not_found_error"))) break;
      console.warn("Modelo no disponible:", model);
    }
    if (!r.ok) {
      console.error("Anthropic", r.status, JSON.stringify(out).slice(0, 500));
      return res.status(r.status === 429 || r.status === 529 ? 503 : 502).json({ error: "claude", detalle: (out.error && out.error.message) || "" });
    }
    const texto = (out.content || []).filter(c => c.type === "text").map(c => c.text).join("");
    return res.json({ texto, uso: out.usage || null });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "interno" });
  }
});
