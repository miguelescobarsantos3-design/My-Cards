#!/bin/bash
# Mis Tarjetas - publica la app en Firebase Hosting (sin tu nombre en el link)
# Uso en Cloud Shell:  bash hosting.sh
set -e
PROY=my-cards-3a148
gcloud config set project $PROY >/dev/null
echo "1/4 Activando Firebase Hosting..."
gcloud services enable firebasehosting.googleapis.com iamcredentials.googleapis.com
TOKEN=$(gcloud auth print-access-token)
API="https://firebasehosting.googleapis.com/v1beta1/projects/$PROY/sites"
H=(-H "Authorization: Bearer $TOKEN" -H "x-goog-user-project: $PROY" -H "Content-Type: application/json")
echo "2/4 Creando la dirección de la app..."
SITIO=""
for S in mycards-app mycards-mx mis-tarjetas-app mistarjetas-mx; do
  if curl -s "${H[@]}" "$API/$S" | grep -q '"defaultUrl"'; then SITIO=$S; echo "   Ya existía: $S"; break; fi
  R=$(curl -s -X POST "${H[@]}" "$API?siteId=$S" -d '{}')
  if echo "$R" | grep -q '"defaultUrl"'; then SITIO=$S; echo "   Creada: $S"; break; fi
  echo "   $S no está disponible, probando otra..."
done
if [ -z "$SITIO" ]; then echo "No se pudo crear la dirección. Mándale captura a Claude."; exit 1; fi
echo "3/4 Creando el permiso para que GitHub publique la app..."
SA=github-deploy@$PROY.iam.gserviceaccount.com
gcloud iam service-accounts describe $SA >/dev/null 2>&1 || gcloud iam service-accounts create github-deploy --display-name="GitHub publica Mis Tarjetas"
for R in roles/firebasehosting.admin roles/run.viewer roles/serviceusage.apiKeysViewer roles/iam.serviceAccountUser; do
  gcloud projects add-iam-policy-binding $PROY --member=serviceAccount:$SA --role=$R --condition=None >/dev/null
done
rm -f ~/clave-github.json
gcloud iam service-accounts keys create ~/clave-github.json --iam-account=$SA >/dev/null
echo "4/4 Listo."
echo
echo "======================================================================"
echo " TU APP QUEDARÁ EN:   https://$SITIO.web.app"
echo " NOMBRE DEL SITIO:    $SITIO      (díselo a Claude)"
echo " Archivo para GitHub: clave-github.json  (descárgalo con ⋮ > Descargar)"
echo "======================================================================"
