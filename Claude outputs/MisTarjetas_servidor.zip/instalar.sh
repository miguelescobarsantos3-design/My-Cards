#!/bin/bash
# Mis Tarjetas - instala el lector con Claude en tu proyecto de Firebase.
# Se corre en Google Cloud Shell:  bash instalar.sh
set -e
PROY=my-cards-3a148
REGION=us-central1
gcloud config set project $PROY >/dev/null
echo "1/5 Activando servicios de Google (1-2 minutos)..."
gcloud services enable cloudfunctions.googleapis.com cloudbuild.googleapis.com run.googleapis.com \
  artifactregistry.googleapis.com secretmanager.googleapis.com firestore.googleapis.com
echo
read -s -p "2/5 Pega tu clave de Anthropic (empieza con sk-ant-, no se va a ver) y presiona Enter: " KEY; echo
if [[ "$KEY" != sk-ant-* ]]; then echo "Esa clave no parece de Anthropic. Vuelve a correr: bash instalar.sh"; exit 1; fi
if gcloud secrets describe anthropic-key >/dev/null 2>&1; then
  printf "%s" "$KEY" | gcloud secrets versions add anthropic-key --data-file=- >/dev/null
else
  printf "%s" "$KEY" | gcloud secrets create anthropic-key --data-file=- --replication-policy=automatic >/dev/null
fi
echo "   Clave guardada en Secret Manager."
echo "3/5 Dando permisos..."
NUM=$(gcloud projects describe $PROY --format='value(projectNumber)')
SA=$NUM-compute@developer.gserviceaccount.com
gcloud secrets add-iam-policy-binding anthropic-key --member=serviceAccount:$SA --role=roles/secretmanager.secretAccessor >/dev/null
for R in roles/cloudbuild.builds.builder roles/datastore.user; do
  gcloud projects add-iam-policy-binding $PROY --member=serviceAccount:$SA --role=$R --condition=None >/dev/null
done
echo "4/5 Publicando el lector (3-5 minutos)..."
gcloud functions deploy leerDocumento --gen2 --runtime=nodejs20 --region=$REGION --source=./servidor \
  --entry-point=leerDocumento --trigger-http --allow-unauthenticated --memory=512Mi --timeout=120s \
  --max-instances=3 --set-secrets=ANTHROPIC_KEY=anthropic-key:latest --quiet
echo "5/5 Revisando el almacenamiento de documentos (Storage)..."
BUCKET=$PROY.firebasestorage.app
if ! gcloud storage buckets describe gs://$BUCKET >/dev/null 2>&1; then
  echo "   Creando Storage (no se pudo desde la consola)..."
  gcloud services enable firebasestorage.googleapis.com
  curl -s -X POST -H "Authorization: Bearer $(gcloud auth print-access-token)" -H "x-goog-user-project: $PROY" \
    -H "Content-Type: application/json" -d '{"location":"US-EAST1"}' \
    "https://firebasestorage.googleapis.com/v1alpha/projects/$PROY/defaultBucket" ; echo
  sleep 5
fi
echo "   Permitiendo que la app abra tus documentos guardados..."
gcloud storage buckets update gs://$BUCKET --cors-file=cors.json || echo "   AVISO: Storage no quedó listo. Mándale captura a Claude."
echo
echo "LISTO. El lector quedó en: https://$REGION-$PROY.cloudfunctions.net/leerDocumento"
